<?php

namespace App\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Session\SessionInterface;

class pageController extends AbstractController
{
    /**
     * @Route("/", name="index")
     */
    public function index(SessionInterface $session)
    {   
        $user = $session->get('nombre_usuario');
        return $this->render('daw2/index.html.twig', [
            'user' => $user,
            'title' => "DAW2 Inicio"
        ]);
    }

    /**
     * @Route("/servicios", name="servicios")
     */
    public function servicios(SessionInterface $session)
    {          $user = $session->get('nombre_usuario');
        return $this->render('daw2/servicios.html.twig', [
            'user' => $user,
            'title' => "DAW2 Servicios"
        ]);
    }
    
    /**
     * @Route("/proyectos/{page2?0}", name="proyectos")
     */
    public function proyectos($page2, SessionInterface $session)
    {
        $user = $session->get('nombre_usuario');
        if ($page2=="2")  return $this->render('daw2/proyectos_page2.html.twig', [
            'proyecto1'=>'/proyectos',
            'proyecto2'=>'/proyectos/2',
            'user' => $user,
            'title' => "DAW2 Proyecto2"
            
        ]);
        if ($page2=="1")  return $this->render('daw2/proyectos.html.twig', [
            'proyecto1'=>'/proyectos',
            'proyecto2'=>'/proyectos/2',
            'user' => $user,
            'title' => "DAW2 Proyecto1"
            ]);
        if ($page2!="1" && $page2!="2") 
        return $this->redirectToRoute('proyectos',[
            'page2'=>'1']);
    }

    /**
     * @Route("/nosotros", name="nosotros")
     */
    public function nosotros(SessionInterface $session)
    {
        $user = $session->get('nombre_usuario');
        return $this->render('daw2/nosotros.html.twig', [
            'user' => $user,
            'title' => "DAW2 Nosotros"
        ]);
    }

    /**
     * @Route("/contacta", name="contacta")
     */
    public function contacta(SessionInterface $session)
    {
        $user = $session->get('nombre_usuario');
        return $this->render('daw2/contacto.html.twig', [
            'user' => $user,
            'title' => "DAW2 Contacta"
        ]);
    }

        /**
     * @Route("/login", name="login")
     */
    public function login(Request $request, SessionInterface $session)
    {   
        $user = $session->get('nombre_usuario');
        return $this->render('daw2/login.html.twig', [
            'user' => $user,
            'title' => "DAW2 Login"
        ]);
    }

    /**
     * @Route("/form/send", name="form_send")
     */
    public function send(Request $request, SessionInterface $session)
    {
        $user = $session->get('nombre_usuario');
        $name= $request->request->get("name");
        $email= $request->request->get("email");
        $website= $request->request->get("website");
        $asunto= $request->request->get("subject");
        $mensaje= $request->request->get("message");
    if ($name!="" && $email!="" && $mensaje!=""){

        return $this->render('daw2/send.html.twig', [
            'name' => $name,
            'email' => $email,
            'website' => $website,
            'subject' => $asunto,
            'message' => $mensaje,
            'user' => $user,
            'title' => "DAW2 EnviarForm"
        ]);}
       else{return $this->redirectToRoute('contacta');}

    }

    /**
     * @Route("/form/sendlogin", name="sendlogin")
     */
    public function sendlogin(Request $request, SessionInterface $session)
    {
        $user= $request->request->get("user");
        $password= $request->request->get("pasword");
    if ($user!="" && $password!=""){

        $session->set('nombre_usuario', $user);
        $session->set('pasword', $password);
            return $this->redirectToRoute('index', [

        ]);}
    else{

           return $this->redirectToRoute('login');

        }

    }

        /**
     * @Route("/form/logOut", name="logOut")
     */
    public function logOut(SessionInterface $session)
    {

        $session->invalidate();
            return $this->redirectToRoute('index', [

        ]);


    }
}
