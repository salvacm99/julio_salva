<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class ProyectosPage2Controller extends AbstractController
{
    /**
     * @Route("/proyectos/page2", name="proyectos_page2")
     */
    public function index()
    {
        return $this->json([
            'message' => 'Welcome to your new controller!',
            'path' => 'src/Controller/ProyectosPage2Controller.php',
        ]);
    }
}
