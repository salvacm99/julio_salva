<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class ProyectosController extends AbstractController
{
    /**
     * @Route("/proyectos", name="proyectos")
     */
    public function index()
    {
        return $this->render([
            'message' => 'Welcome to your new controller!',
            'path' => 'src/Controller/ProyectosController.php',
        ]);
    }
}
