<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class NosotrosController extends AbstractController
{
    /**
     * @Route("/nosotros", name="nosotros")
     */
    public function index()
    {
        return $this->render([
            'message' => 'Welcome to your new controller!',
            'path' => 'src/Controller/NosotrosController.php',
        ]);
    }
}
